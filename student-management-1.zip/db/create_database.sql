-- Run this on your MySQL server before starting the app (or let JPA create the tables).
CREATE DATABASE IF NOT EXISTS studentdb CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
