# Student Management (Spring Boot + Hibernate + MySQL)

## What this is
A minimal CRUD web application for managing students using:
- Java 17
- Spring Boot (Spring MVC)
- Spring Data JPA (Hibernate)
- Thymeleaf
- MySQL
- Maven

## How to run locally

1. Prerequisites:
   - Java 17+ installed
   - Maven installed
   - MySQL server running

2. Create the database (run the SQL):
   - `mysql -u root -p < db/create_database.sql`
   - or create database `studentdb` manually.

3. Edit `src/main/resources/application.properties` and set your MySQL username & password.

4. Build and run:
   - `mvn clean package`
   - `mvn spring-boot:run`
   - or run the generated jar: `java -jar target/student-management-0.0.1-SNAPSHOT.jar`

5. Open in browser:
   - `http://localhost:8080/students`

## Notes
- JPA `spring.jpa.hibernate.ddl-auto=update` will create tables automatically.
- To reset the DB, drop the `students` table or the `studentdb` database.
